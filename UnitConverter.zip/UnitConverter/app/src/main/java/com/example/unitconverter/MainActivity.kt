package com.example.unitconverter

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt


class MainActivity : AppCompatActivity() {
    private var status: Boolean = false



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val  toggle = findViewById<ToggleButton>(R.id.toggleButton)
        val textStat = findViewById<TextView>(R.id.setToText)
        val userInput = findViewById<TextView>(R.id.inputText)
        val runButton = findViewById<Button>(R.id.runButton)

        setTo(textStat,userInput)

        runButton.setOnClickListener{
            convertEntry(userInput)
        }

        toggle.setOnCheckedChangeListener {_, isChecked ->
            if(isChecked){
                this.status = true
            }
            else {
                this.status = false
                 // isn't checked
            }
            setTo(textStat,userInput)
        }
    }

    fun convertEntry(input: TextView) {
        val value: String = input.text.toString()
        try {

            if (!status) {
                val math: Double = java.lang.Double.parseDouble(value.toString())

                val celceius: Double = ((math - 32) * 0.5555555555555556)
                val update: Int = celceius.roundToInt()
                input.setText(update.toString())

            } else {
                val math: Double = java.lang.Double.parseDouble(value.toString())

                val fahrenheit: Double = (math * 1.8 + 32)
                val update: Int = fahrenheit.roundToInt()
                input.setText(update.toString())
            }
        }
        catch (e: Exception){
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    fun setTo(view: TextView, input: TextView){
        if(!status) {
            view.text = "Set to celsius"
           input.hint = "Enter degrees in fahrenheit"
        }
        else{
            view.text = "Set to fahrenheit"
           input.hint = "Enter degrees in celsius"
        }

    }


}