package com.example.unitconverter

import android.widget.TextView
import android.widget.Toast
import org.junit.Test

import org.junit.Assert.*
import org.junit.Ignore
import kotlin.math.roundToInt

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Ignore
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun convertingCelsiusIntoFahrenhiet(){
        val math: Double = 50.0
        val expected = 122

        val fahrenheit: Double = (math * 1.8 + 32)
        val update: Int = fahrenheit.roundToInt()

        assertEquals(expected, update)
    }

    @Test
    fun convertingFahrenhietIntoCelsius(){
        val math: Double = 10.0
        val expected = -12

        val celceius: Double = ((math - 32) * 0.5555555555555556)
        val update: Int = celceius.roundToInt()

        assertEquals(expected, update)
    }

    @Test
    fun testIfMapToALogic(){
        var status: Boolean = false
        val math: Double = 10.0
        val expected = -12

        try {

            if (!status) {


                val celceius: Double = ((math - 32) * 0.5555555555555556)
                val update: Int = celceius.roundToInt()
                assertEquals(expected, update)


            } else {

                val fahrenheit: Double = (math * 1.8 + 32)
                val update: Int = fahrenheit.roundToInt()

                assertEquals(expected, update)

            }
        }
        catch (e: Exception){

            e.printStackTrace()
        }
    }




}